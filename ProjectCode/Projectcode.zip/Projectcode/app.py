import io
import torch
import json
import argparse

from matplotlib import pyplot as plt
from torchvision import transforms
from PIL import Image
from flask import Flask, request, jsonify, render_template
from argparse import ArgumentParser
import os
import sys
from utils.inference import inference_model, init_model, show_result_pyplot
from utils.train_utils import get_info, file2dict
from models.build import BuildNet
import numpy as np
sys.path.insert(0, os.getcwd())

app = Flask(__name__)

# ResNet50 Model
parser1 = ArgumentParser()
parser1.add_argument('--config', default='models/resnet/resnet50.py', help='Config file')
parser1.add_argument('--classes-map', default='datasets/annotations.txt', help='classes map of datasets')
parser1.add_argument('--device', default='cuda', help='Device used for inference')
args1 = parser1.parse_args()
classes_names, label_names = get_info(args1.classes_map)

model_cfg1, train_pipeline1, val_pipeline1, data_cfg1, lr_config1, optimizer_cfg1 = file2dict(args1.config)
model1 = BuildNet(model_cfg1)

# AlexNet Model
parser2 = ArgumentParser()
parser2.add_argument('--config', default='models/alexnet/alexnet_.py', help='Config file')
args2 = parser2.parse_args()
model_cfg2, train_pipeline2, val_pipeline2, data_cfg2, lr_config2, optimizer_cfg2 = file2dict(args2.config)
model2 = BuildNet(model_cfg2)

#Convenext Model
parser3 = ArgumentParser()
parser3.add_argument('--config', default='models/convnext/convnext_small.py', help='Config file')
args3 = parser3.parse_args()
model_cfg3, train_pipeline3, val_pipeline3, data_cfg3, lr_config3, optimizer_cfg3 = file2dict(args3.config)
model3 = BuildNet(model_cfg3)

#DenseNet Model
parser4 = ArgumentParser()
parser4.add_argument('--config', default='models/densenet/densenet121.py', help='Config file')
args4 = parser4.parse_args()
model_cfg4, train_pipeline4, val_pipeline4, data_cfg4, lr_config4, optimizer_cfg4 = file2dict(args4.config)
model4 = BuildNet(model_cfg4)

#EfficientNet Model
parser5 = ArgumentParser()
parser5.add_argument('--config', default='models/efficientnet/efficientnet_b1.py', help='Config file')
args5 = parser5.parse_args()
model_cfg5, train_pipeline5, val_pipeline5, data_cfg5, lr_config5, optimizer_cfg5 = file2dict(args5.config)
model5 = BuildNet(model_cfg5)

#MobileNet Model
parser6 = ArgumentParser()
parser6.add_argument('--config', default='models/mobilenet/mobilenet_v3_small.py', help='Config file')
args6 = parser6.parse_args()
model_cfg6, train_pipeline6, val_pipeline6, data_cfg6, lr_config6, optimizer_cfg6 = file2dict(args6.config)
model6 = BuildNet(model_cfg6)

#VGG Model
parser7 = ArgumentParser()
parser7.add_argument('--config', default='models/vgg/vgg11_bn.py', help='Config file')
args7 = parser7.parse_args()
model_cfg7, train_pipeline7, val_pipeline7, data_cfg7, lr_config7, optimizer_cfg7 = file2dict(args7.config)
model7 = BuildNet(model_cfg7)

#Vision Transformer Model
parser8 = ArgumentParser()
parser8.add_argument('--config', default='models/vision_transformer/vit_base_p16_224.py', help='Config file')
args8 = parser8.parse_args()
model_cfg8, train_pipeline8, val_pipeline8, data_cfg8, lr_config8, optimizer_cfg8 = file2dict(args8.config)
model8 = BuildNet(model_cfg8)

@app.route('/',methods=["GET", "POST"])
def main():
    return render_template('Predict.html')


@app.route("/predictResnet50", methods=["POST"])
def predictResnet50():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)
            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')


            model = init_model(model1, data_cfg1, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline1, classes_names, label_names)
            print("class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: Resnet50 , class: {}   prob: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)


@app.route("/predictAlexNet", methods=["POST"])
def predictAlexNet():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')
            model= init_model(model2, data_cfg2, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline2, classes_names, label_names)
            print("Model: Alexnet","class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: Alexnet , class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)


@app.route("/predictConvnext", methods=["POST"])
def predictConvnext():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')
            model = init_model(model3, data_cfg3, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline3, classes_names, label_names)
            print("Model: Convnext", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: Convnext  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)

@app.route("/predictDenseNet", methods=["POST"])
def predictDenseNet():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')
            model = init_model(model4, data_cfg4, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline4, classes_names, label_names)
            print("Model: DenseNet", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: DenseNet  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)


@app.route("/predictEfficientNet", methods=["POST"])
def predictEfficientNet():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')
            model = init_model(model5, data_cfg5, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline5, classes_names, label_names)
            print("Model: EfficientNet", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: EfficientNet  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)

@app.route("/predictMobileNet", methods=["POST"])
def predictMobileNet():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')

            model = init_model(model6, data_cfg6, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline6, classes_names, label_names)

            print("Model: MobileNet", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: MobileNet  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)

@app.route("/predictVGG", methods=["POST"])
def predictVGG():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')

            model = init_model(model7, data_cfg7, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline7, classes_names, label_names)

            print("Model: VGG", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print_res = "Model: VGG  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)


@app.route("/predictVisionTransformer", methods=["POST"])
def predicVisionTransformer():
    data = {"success": False}
    if request.method == 'POST':
        if request.files.get("image"):
            # Read the image in PIL format
            image = request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            image = np.array(image)


            if torch.cuda.is_available():
                device = torch.device('cuda:0')
            else:
                device = torch.device('cpu')

            model = init_model(model8, data_cfg8, device=device, mode='eval')
            result = inference_model(model, image, val_pipeline8, classes_names, label_names)

            print("Model: Vision Transformer", "class: ", result['pred_class'], "Pred_score", result['pred_score'])
            print(label_names)
            print_res = "Model: Vision Transformer  class: {}   Probability Score: {:.6}".format(result['pred_class'], result['pred_score'])
            data['predictions'] = [print_res]
            data["success"] = True
    return jsonify(data)

if __name__ == "__main__":
    app.run()

