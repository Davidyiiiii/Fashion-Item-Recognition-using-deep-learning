import os
import sys
sys.path.insert(0,os.getcwd())


def gen_anno(classes_path, datasets_path):
    class_name_list = []
    for ele_dir in ["train", "test"]:
        datasets_path_ = os.path.join(datasets_path, ele_dir)
        for class_name in os.listdir(datasets_path_):
            class_name_list.append(class_name)
    class_name_list = list(set(class_name_list))
    out_str = ""
    for index, ele in enumerate(class_name_list):
        out_str += str(ele) + '\t' + str(index) + '\n'
    
    with open(classes_path, 'w') as f:
        f.write(out_str.strip())

# 获得类名、索引
def get_info(classes_path):
    with open(classes_path, encoding='utf-8') as f:
        class_names = f.readlines()
    names = []
    indexs = []
    for data in class_names:
        name,index = data.split('\t')
        names.append(name)
        indexs.append(int(index))
        
    return names,indexs

# 生成train.txt和test.txt
def gen_txt(classes_path, datasets_path):
    classes, class_indexs = get_info(classes_path)
    
    for ele_dir in ["train", "test"]:
        txt_file = open(os.path.join(datasets_path, str(ele_dir)+'.txt'), 'w')
        datasets_path_ = os.path.join(datasets_path, ele_dir)
        classes_name      = os.listdir(datasets_path_)
        
        for name in classes_name:
            if name not in classes:
                continue
            cls_id = class_indexs[classes.index(name)]
            images_path = os.path.join(datasets_path_, name)
            images_name = os.listdir(images_path)
            for photo_name in images_name:
                _, postfix = os.path.splitext(photo_name)
                if postfix not in ['.jpg', '.png', '.jpeg','.JPG', '.PNG', '.JPEG']:
                    continue
                txt_file.write('%s'%(os.path.join(images_path, photo_name)) + ' ' + str(cls_id))
                txt_file.write('\n')
        txt_file.close()


if __name__ == "__main__":
    classes_path    = 'datasets/datasets/annotations.txt'
    datasets_path   = 'datasets'
    gen_anno(classes_path, datasets_path)
    gen_txt(classes_path, datasets_path)
